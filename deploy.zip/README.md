# flask-app
## A simple flask-app with API endpoints
## Use AWS Codebuild to run the build of the application