#!/bin/bash
echo "Installing Flask dependencies..."
cd /home/ec2-user/flask-app-deploy
pip install -r requirements.txt